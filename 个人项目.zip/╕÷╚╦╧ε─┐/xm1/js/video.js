/**
 * Created by Administrator on 2016/10/18.
 */
player = new YKU.Player('youkuplayer',{
    styleid: '0',
    client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
    vid: 'XNjU0ODc4OTQ4',
    newPlayer: true
});
function playVideo(){
    player.playVideo();
}


console.log($("#sp1"))
$("#sp1").click(function(){
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        vid: 'XMTQxNjc1MDE0OA',
        newPlayer: true
    });
})
$("#sp2").click(function(){
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        vid: 'XMTUzMzMwODIzNg',
        newPlayer: true
    });

});
$("#sp3").click(function(){
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        vid: 'XMTI3MTAwNTg4MA',
        newPlayer: true
    });

});
$("#sp4").click(function(){
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        vid: 'XMTMwNzQwMTcwMA',
        newPlayer: true
    });

});
$("#sp5").click(function(){
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        vid: 'XOTM1MTEwODQ0',
        newPlayer: true
    });

});
$("#sp6").click(function(){
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        vid: 'XMTU1OTAwMDU2MA',
        newPlayer: true
    });

});
var ul=document.getElementById("dh");
var li=ul.getElementsByTagName("li");
console.log(li[0])
li[0].onclick=function(){
    $("#bf").css("display","block");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        show_related: true,
        vid: 'XMTUzNzA2MjQ4OA',
        newPlayer: true
    });
    $("#cd").css("display","none");
};

li[1].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        show_related: true,
        autoplay: true,
        vid: 'XMTY4ODg3Nzc5Ng',
        newPlayer: true
    })
};
li[2].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTUyODY2NDU4MA',
        newPlayer: true
    })
};
li[3].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTY3ODAyOTM1Mg',
        newPlayer: true
    });
};
li[4].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTUzNTg0ODM1Ng',
        newPlayer: true
    });
};
li[5].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTUzMzE3MzE3Ng',
        newPlayer: true
    });
};
li[6].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTQzMDQ4MjcyMA',
        newPlayer: true
    });
};
li[7].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTUwODIyMzMyMA',
        newPlayer: true
    });
};
li[8].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTU5ODg1MTk3Mg',
        newPlayer: true
    });
};
li[9].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTUxNDM0MjA3Mg',
        newPlayer: true
    });
};
li[10].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTYxNDU5MzA3Ng',
        newPlayer: true
    });
};
li[11].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTM5OTY1NTI4MA',
        newPlayer: true
    });
};
li[12].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTU1MDY5MzE2NA',
        newPlayer: true
    });
};
li[13].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTYzOTU2MDE2OA',
        newPlayer: true
    });
};
li[14].onclick=function(){
    $("#bf").css("display","block");
    $("#cd").css("display","none");
    player = new YKU.Player('youkuplayer',{
        styleid: '0',
        client_id: 'YOUR YOUKUOPENAPI CLIENT_ID',
        autoplay: true,
        vid: 'XMTU2NTkyNDM0MA',
        newPlayer: true
    });
};


$("#mp3").click(function(){
    $("#xx").css("display","none");
    $("#cd").css("display","none");
    $("#bf").css("display","none");
    $("#cd").css("display","none");
    $("#yinyue").css("display","block");
});