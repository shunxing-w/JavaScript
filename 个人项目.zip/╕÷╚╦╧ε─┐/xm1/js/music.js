/**
 * Created by Administrator on 2016/10/19.
 */

$(function() {
    $( "#beginning" ).button({
        text: false,
        icons: {
            primary: "ui-icon-seek-start"
        }
    });
    $( "#rewind" ).button({
        text: false,
        icons: {
            primary: "ui-icon-seek-prev"
        }
    });
    $( "#play" ).button({
        text: false,
        icons: {
            primary: "ui-icon-play"
        }
    })

    $( "#stop" ).button({
        text: false,
        icons: {
            primary: "ui-icon-stop"
        }
    })
        .click(function() {
            $( "#play" ).button( "option", {
                label: "play",
                icons: {
                    primary: "ui-icon-play"
                }
            });
        });

    $( "#forward" ).button({
        text: false,
        icons: {
            primary: "ui-icon-seek-next"
        }
    });

    $( "#end" ).button({
        text: false,
        icons: {
            primary: "ui-icon-seek-end"
        }
    });
    //��ͣ ����
    var flang =true;
    var myaud = $('#video1')[0];

    $('#play').click(function(){
        var options;
        if(flang){
            myaud.play();
            options = {
                label: "pause",
                icons: {
                    primary: "ui-icon-pause"
                }
            };
        }else{
            myaud.pause();
            options = {
                label: "play",
                icons: {
                    primary: "ui-icon-play"
                }
            };
        }
        flang =!flang;
        $( this ).button( "option", options );
    })
    //����
    $('#range')[0].oninput=function(){
        myaud.volume=this.value*0.01;
    }
    //����ʱ����ʾ
    var time = $('#time');
    var schedule=document.getElementById('schedule');

    function getTime() {
        min =  parseInt(myaud.duration / 60);
        second = parseInt(myaud.duration % 60);
        cmin =  parseInt(myaud.currentTime / 60);
        csec = parseInt(myaud.currentTime % 60);
        var s=(cmin*60+csec);
        schedule.value=s;
        schedule.max=min*60+second;
        time.html(prefixZero(cmin,2,0) + ':' + prefixZero(csec,2,0) + '/' + prefixZero(min,2,0) + ':' + prefixZero(second,2,0));
    }

    setInterval(getTime,1000);
    function prefixZero(num,n,arg) {
        return (Array(n).join(arg) + num).slice(-n);
    }

    //�����л�
    var gqsz=["http://mp3.haoduoge.com/s/2016-10-19/1476854136.mp3","audio/mo.mp3","http://up.haoduoge.com:82/mp3/2016-10-19/1476854175.mp3","http://up.haoduoge.com:82/mp3/2016-10-19/1476854175.mp3","http://up.haoduoge.com:82/mp3/2016-10-19/1476854175.mp3","http://up.haoduoge.com:82/mp3/2016-10-19/1476854175.mp3","http://up.haoduoge.com:82/mp3/2016-10-19/1476854175.mp3"]
    var a=0;
    var img=document.getElementById('img');
    $('#end').click(function () {
        a++;
        if(a>gqsz.length-1){
            a=0;
        }
        myaud.src = gqsz[a];
        console.log(a);
        switch (a){
            case 0:img.src="xzq.jpeg";break;
            case 1:img.src="nay.jpg";break;
            case 2:img.src="bber.png";break;
            case 3:img.src="dxy.jpg";break;
            case 4:img.src="hcy.jpeg";break;
            case 5:img.src="101.jpg";break;
            case 6:img.src="dyht.jpg";break;
        }

    });
    $('#beginning').click(function () {
        a--;
        if(a<0){
            a=gqsz.length-1;
        }
        myaud.src = gqsz[a];
        console.log(a);
        switch (a){
            case 0:img.src="";break;
            case 1:img.src="nay.jpg";break;
            case 2:img.src="bber.png";break;
            case 3:img.src="dxy.jpg";break;
            case 4:img.src="hcy.jpeg";break;
            case 5:img.src="101.jpg";break;
            case 6:img.src="dyht.jpg";break;
        }

    });
    //����������
    var box=document.getElementById("gqml");
    var ml=box.getElementsByTagName('li');

    ml[0].onclick=function(){
        myaud.src = gqsz[0];
        img.src="xzq.jpeg";
    }
    ml[1].onclick=function(){
        myaud.src = gqsz[1];
        img.src="nay.jpg";

    }
    ml[2].onclick=function(){
        myaud.src = gqsz[2];
        img.src="bber.png";

    }
    ml[3].onclick=function(){
        myaud.src = gqsz[3];
        img.src="dxy.jpg";

    }
    ml[4].onclick=function(){
        myaud.src = gqsz[4];
        img.src="hcy.jpeg";

    }
    ml[5].onclick=function(){
        myaud.src = gqsz[5];
        img.src="101.jpg";

    }
    ml[6].onclick=function(){
        myaud.src = gqsz[6];
        img.src="dyht.jpg";

    }
    $("#gqlb").click(function(){
        $("#flip").slideToggle("slow");
    });
    /* for(var i= 0;i<ml.length;i++){
     ml[i].index=i;
     ml[i].onclick=function(){

     for(var j=0;j<ml.length;j++){
     ml[j].className="";
     }
     this.className="bac"
     }
     }*/

});

